################################################################################
## 《对岸有灯》——全局定义
##
## 本文件包含：角色定义、贯穿全篇的状态旗标。
## 章节内容见 ch01~ch05.rpy，全部结局见 endings.rpy，主入口在 script.rpy。
################################################################################

## 旁白（第一人称"我"：陈默）→ 电子小说模式
define narrator = nvl_narrator

## 选项 → 小说模式（选项以正文形式列在页面末尾）
define menu = nvl_menu

## ——出场角色——
## 老猫：同监室的老手，广东人，被困园区第四年
define cat = Character("老猫", kind=nvl, color="#c8b98a")

## 阿芸：广西女生，客服组，二十二岁
define yun = Character("阿芸", kind=nvl, color="#b8a8d2")

## K先生：话务组组长，人称"K哥"，笑面虎
define k = Character("K先生", kind=nvl, color="#d29d8a")

## 阿彪：看守头目，收东西也收人
define biao = Character("阿彪", kind=nvl, color="#8f8f8f")

## 丹丹：缅族守卫，会说一点中文，收话梅和烟
define dan = Character("丹丹", kind=nvl, color="#9dc2a8")

## 老周：中介，"物流公司"的"商务"
define zhou = Character("老周", kind=nvl, color="#a0a0a0")

## 妈妈：电话那头的声音
define mom = Character("妈妈", kind=nvl, color="#e0c9a6")

## 广播：园区每天响六次的声音
define gong = Character("广播", kind=nvl, color="#707070")

## 居中旁白：用于结局标题与序章标题（NVL 条目内文字居中）
define c_center = Character(None, kind=nvl, what_textalign=0.5)

## ——贯穿全篇的状态旗标——
## 注意：全部使用 default 声明，保证存档与回档安全。

default sd_card = False        # 备用存储卡是否藏了下来
default sd_where = ""          # 藏匿位置："shoe"（鞋垫下）/ "camera"（相机电池仓）/ ""
default trust_zhou = False     # 是否轻信了中介老周
default by_boat = False        # 是否走了夜船入境（决定对河的第一印象）
default watch_time = False     # 是否掌握换防时刻表
default know_dog = False       # 是否发现水房后的狗已死（狗洞线关键）
default know_river = False     # 是否了解过河的情报
default bribe = ""             # 贿赂对象："biao" / "dan" / ""
default performance = "mid"    # 业绩态度："good" / "mid" / "bad"
default mom_call = ""          # 家属电话："police" / "money" / "none"
default yun_promise = False    # 是否答应带阿芸一起走
